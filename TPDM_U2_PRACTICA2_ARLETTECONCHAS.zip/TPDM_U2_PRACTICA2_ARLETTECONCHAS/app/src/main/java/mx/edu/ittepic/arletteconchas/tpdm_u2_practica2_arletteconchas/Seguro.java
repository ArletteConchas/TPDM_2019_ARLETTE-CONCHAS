package mx.edu.ittepic.arletteconchas.tpdm_u2_practica2_arletteconchas;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

public class Seguro {
    private String idseguro;
    private String descripcion;
    private String fecha;
    private String tipo;
    private String telefono;
    private BaseDatos base;
    String error;

    public Seguro(Activity activity){
        base = new BaseDatos(activity,"EMPRESA",null,1);
    }

    public Seguro(String id, String des, String fe, String t, String tel) {
        idseguro = id;
        descripcion = des;
        fecha = fe;
        tipo = t;
        telefono = tel;
    }

    public boolean insertar(Seguro seguro){
        try{
            SQLiteDatabase transaccioninsertar = base.getWritableDatabase();
            ContentValues datos = new ContentValues();
            datos.put("IDSEGURO",seguro.getIdSeguro());
            datos.put("DESCRIPCION",seguro.getDescripcion());
            datos.put("FECHA",seguro.getFecha());
            datos.put("TIPO",seguro.getTipo());
            datos.put("TELEFONO",seguro.getTelefono());
            long resultado = transaccioninsertar.insert("SEGURO",null,datos);
            transaccioninsertar.close();
            if(resultado ==-1) return false;
        }catch (SQLiteException e){
            error = e.getMessage();
            return false;
        }
        return true;
    }

    public Seguro[] consultar(){
        SQLiteDatabase transaccionconsultar = base.getReadableDatabase();
        Seguro[] result = null;
        Cursor c = transaccionconsultar.rawQuery("SELECT * FROM SEGURO",null);
        if(c.moveToFirst()){
            result = new Seguro[c.getColumnCount()];
            for (int i=0;c.moveToNext();i++){
                String id= c.getString(0);
                String desc= c.getString(1);
                String fecha= c.getString(2);
                String tipo= c.getString(3);
                String tel= c.getString(4);

                result[i]= new Seguro(id,desc,fecha,tipo,tel);
            }
        }
        return result;
    }

    public Seguro[] consultar(String columna, String clave){
        Seguro[] resultado= null;
        try{
            SQLiteDatabase transaccionconsultar = base.getReadableDatabase();
            String SQL = "SELECT * FROM SEGURO WHERE IDSEGURO='"+clave+"'";
            if(columna.startsWith("DESCRIPCION")){
                SQL = "SELECT * FROM SEGURO WHERE DESCRIPCION='"+clave+"'";
            }
            if(columna.startsWith("FECHA")){
                SQL = "SELECT * FROM SEGURO WHERE FECHA='"+clave+"'";
            }
            if(columna.startsWith("TIPO")){
                SQL = "SELECT * FROM SEGURO WHERE TIPO='"+clave+"'";
            }
            if(columna.startsWith("TELEFONO")){
                SQL = "SELECT * FROM SEGURO WHERE TELEFONO='"+clave+"'";
            }
            Cursor c = transaccionconsultar.rawQuery(SQL, null);
            if(c.moveToFirst()){
                resultado = new Seguro[c.getCount()];
                int pos = 0;
                do{
                    resultado[pos]=new Seguro(c.getString(0),c.getString(1),
                            c.getString(2),
                            c.getString(3),c.getString(4));
                    pos++;
                }while (c.moveToNext());
            }
            transaccionconsultar.close();
        }catch (SQLiteException e) {
            return null;
        }
        return resultado;
    }

    public boolean eliminar(String ID) {
        int resultado=0;
        try {
            SQLiteDatabase transaccioneliminar = base.getWritableDatabase();
            String id[] = {ID};
            resultado = transaccioneliminar.delete("SEGURO", "IDSEGURO=?", id);
            transaccioneliminar.close();
        } catch (SQLiteException e) {
            error = e.getMessage();
            return false;
        }
        return resultado>0;
    }

    public boolean actualizar(Seguro seguro){
        try {
            SQLiteDatabase transaccionactualizar = base.getWritableDatabase();
            ContentValues datos = new ContentValues();
            String id[] = {seguro.getIdSeguro()};
            datos.put("DESCRIPCION",seguro.getDescripcion());
            datos.put("FECHA",seguro.getFecha());
            datos.put("TIPO",seguro.getTipo());
            datos.put("TELEFONO",seguro.getTelefono());
            long resultado = transaccionactualizar.update("SEGURO",datos, "TELEFONO=?", id);
            transaccionactualizar.close();
            if (resultado == -1) return false;
        }catch (SQLiteException e){
            error = e.getMessage();
            return false;
        }
        return true;
    }


    public String getIdSeguro() {
        return idseguro;
    }

    public void setIdSeguro(String id) {
        idseguro = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String des) {
        descripcion = des;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fe) {
        fecha = fe;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String t) {
        tipo = t;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String tel) {
        telefono = tel;
    }
}
