package mx.edu.ittepic.arletteconchas.tpdm_u2_practica2_arletteconchas;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Main4Activity extends AppCompatActivity {
    EditText consulta;
    Button buscar, actualiza, elimina, finaliza;
    TextView txttel, txtnombre, txtdire, txtf, txtnoseg, txtdes, txttipo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        consulta = findViewById(R.id.edconsultar);
        buscar = findViewById(R.id.btbuscar);
        actualiza = findViewById(R.id.btactualizar);
        elimina = findViewById(R.id.bteliminar);
        finaliza = findViewById(R.id.btfinalizarconsultar);
        txttel = findViewById(R.id.textotelefono);
        txtnombre = findViewById(R.id.textonombre);
        txtdire = findViewById(R.id.textodireccion);
        txtf = findViewById(R.id.textofecha);
        txtnoseg = findViewById(R.id.textoseguro);
        txtdes = findViewById(R.id.textodescripcion);
        txttipo = findViewById(R.id.textotipo);

        actualiza.setEnabled(false);
        elimina.setEnabled(false);
        txttel.setEnabled(false);
        txtnombre.setEnabled(false);
        txtdire.setEnabled(false);
        txtf.setEnabled(false);
        txtnoseg.setEnabled(false);
        txtdes.setEnabled(false);
        txttipo.setEnabled(false);

        buscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                consultar();
            }
        });

        actualiza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        elimina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eliminar();
            }
        });

        finaliza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentar = new Intent(Main4Activity.this, Main3Activity.class);
                startActivity(intentar);
            }
        });
    }

    public void consultar(){

            Propietario p = new Propietario(this);
            Propietario[] propietarios = p.consultar("TELEFONO",consulta.getText().toString());
            Seguro s = new Seguro(this);
            Seguro[] seguros = s.consultar("IDSEGURO",consulta.getText().toString());
            if(propietarios==null || seguros==null){
                mensaje("ERROR", "NO HAY RESULTADOS");
            }else{
                txttel.setEnabled(true);
                txtnombre.setEnabled(true);
                txtdire.setEnabled(true);
                txtf.setEnabled(true);
                actualiza.setEnabled(true);
                elimina.setEnabled(true);
                txtnoseg.setEnabled(true);
                txtdes.setEnabled(true);
                txttipo.setEnabled(true);
                for (int i=0;i<propietarios.length;i++){
                    Propietario temp= propietarios[i];
                    txttel.setText(temp.getTelefono());
                    txtnombre.setText(temp.getNombre());
                    txtdire.setText(temp.getDomicilio());
                    txtf.setText(temp.getFecha());
                }
                for (int i=0;i<seguros.length;i++){
                    Seguro temp= seguros[i];
                    txtnoseg.setText(temp.getIdSeguro());
                    txtdes.setText(temp.getDescripcion());
                    txttipo.setText(temp.getTipo());
                }
            }
    }

    private void mensaje(String titulo, String Mensaje) {
        AlertDialog.Builder a=new AlertDialog.Builder(this);
        a.setTitle(titulo).setMessage(Mensaje).setPositiveButton("Aceptar",null).show();
    }

    private void eliminar() {
            AlertDialog.Builder alerta = new AlertDialog.Builder(this);
            alerta.setTitle("Atencion");
            alerta.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String mensaje="";
                    Propietario propietario = new Propietario(Main4Activity.this);
                    Seguro seguro = new Seguro(Main4Activity.this);
                    boolean resultado = propietario.eliminar(consulta.getText().toString());
                    boolean resultado2 = seguro.eliminar(consulta.getText().toString());
                    if (resultado) {
                        if(resultado2) {
                            mensaje = "Se elimino Correctamente";
                        }
                    }else {
                        mensaje="Error al Elimnar";
                    }
                    Toast.makeText(Main4Activity.this,mensaje,Toast.LENGTH_LONG).show();
                }
            });
            alerta.show();
    }

}
