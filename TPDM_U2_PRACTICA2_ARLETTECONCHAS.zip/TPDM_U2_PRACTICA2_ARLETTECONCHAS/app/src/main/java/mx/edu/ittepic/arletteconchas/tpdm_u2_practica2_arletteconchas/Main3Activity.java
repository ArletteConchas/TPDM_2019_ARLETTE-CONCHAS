package mx.edu.ittepic.arletteconchas.tpdm_u2_practica2_arletteconchas;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class Main3Activity extends AppCompatActivity {
    Button insertar, consultar;
    ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        insertar = findViewById(R.id.btinsertar);
        consultar = findViewById(R.id.btconsultar);
        lista = findViewById(R.id.listainicio);

        insertar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funcionInsertar();
            }
        });

        consultar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funcionConsultar();
            }
        });
    }

    public void funcionInsertar(){
        Intent intentar = new Intent(Main3Activity.this, MainActivity.class);
        startActivity(intentar);
    }

    public void funcionConsultar(){
        Intent intentar = new Intent(Main3Activity.this, Main4Activity.class);
        startActivity(intentar);
    }

    @Override
    protected void onStart() {
        Propietario p = new Propietario(this);
        Propietario[] vector = p.consultar();
        String[] telefononombre=null;
        if(vector==null){
            telefononombre = new String[1];
            telefononombre[0]="NO HAY PROYECTOS";
        }else{
            telefononombre = new String[vector.length];
            for (int i=0;i<vector.length;i++){
                Propietario temp= vector[i];
                telefononombre[i]=temp.getTelefono()+"\n"+temp.getNombre();
            }
        }
        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(Main3Activity.this,
                android.R.layout.simple_list_item_1,telefononombre);
        lista.setAdapter(adaptador);
        super.onStart();
    }

}
