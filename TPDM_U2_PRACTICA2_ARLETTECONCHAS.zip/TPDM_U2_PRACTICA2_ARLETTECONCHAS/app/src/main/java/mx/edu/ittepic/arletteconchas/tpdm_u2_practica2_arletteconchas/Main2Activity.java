package mx.edu.ittepic.arletteconchas.tpdm_u2_practica2_arletteconchas;

import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main2Activity extends AppCompatActivity {
    EditText noseguro, descripcion, fecha, tipo, telefono;
    Button finalizar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        noseguro = findViewById(R.id.edidseguro);
        descripcion = findViewById(R.id.eddescripcion);
        fecha = findViewById(R.id.edfechaseguro);
        tipo = findViewById(R.id.edtipo);
        telefono = findViewById(R.id.edtelefono);
        finalizar = findViewById(R.id.btfinalizar);

        finalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fin();
            }
        });
    }

    public void fin(){
        try{
            boolean respuesta = false;
            Seguro s = new Seguro(this);
            respuesta = s.insertar(new Seguro(noseguro.getText().toString(),descripcion.getText().toString(),
                    fecha.getText().toString(),tipo.getText().toString(),telefono.getText().toString()));
            if (respuesta) {
                mensaje("EXITO","SE PUDO ISNERTAR");
            } else {
                mensaje(":(","NO SE PUDO INSERTAR");
            }
            Intent intentar = new Intent(Main2Activity.this, Main3Activity.class);
            startActivity(intentar);
        }catch (SQLiteException e){
            mensaje("ATENCION","ERROR JIJI");
        }
    }

    private void mensaje(String titulo, String Mensaje) {
        AlertDialog.Builder a=new AlertDialog.Builder(this);
        a.setTitle(titulo).setMessage(Mensaje).setPositiveButton("Aceptar",null).show();
    }
}
