package mx.edu.ittepic.arletteconchas.tpdm_u2_practica2_arletteconchas;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

public class Propietario {
    private String telefono;
    private String nombre;
    private String domicilio;
    private String fecha;
    private BaseDatos base;
    String error;

    public Propietario(Activity activity){
        base = new BaseDatos(activity,"EMPRESA",null,1);
    }

    public Propietario(String tel, String nom, String dom, String fe) {
        telefono = tel;
        nombre = nom;
        domicilio = dom;
        fecha = fe;
    }

    public boolean insertar(Propietario propietario){
        try{
            SQLiteDatabase transaccioninsertar = base.getWritableDatabase();
            ContentValues datos = new ContentValues();
            datos.put("TELEFONO",propietario.getTelefono());
            datos.put("NOMBRE",propietario.getNombre());
            datos.put("DOMICILIO",propietario.getDomicilio());
            datos.put("FECHA",propietario.getFecha());
            long resultado = transaccioninsertar.insert("PROPIETARIO",null,datos);
            transaccioninsertar.close();
            if(resultado ==-1) return false;
        }catch (SQLiteException e){
            error = e.getMessage();
            return false;
        }
        return true;
    }

    public Propietario[] consultar(){
        SQLiteDatabase transaccionconsultar = base.getReadableDatabase();
        Propietario[] resultado = null;
        Cursor c = transaccionconsultar.rawQuery("SELECT * FROM PROPIETARIO",null);
        if(c.moveToFirst()){
            resultado = new Propietario[c.getColumnCount()];
            for (int i=0;c.moveToNext();i++){
                String tel= c.getString(0);
                String nom= c.getString(1);
                String dom= c.getString(2);
                String fecha= c.getString(3);
                resultado[i]= new Propietario(tel,nom,dom,fecha);
            }
        }
        return resultado;
    }

    public Propietario[] consultar(String columna, String clave){
        Propietario[] resultado= null;
        try{
            SQLiteDatabase transaccionconsultar = base.getReadableDatabase();
            String SQL = "SELECT * FROM PROPIETARIO WHERE TELEFONO='"+clave+"'";
            if(columna.startsWith("NOMBRE")){
                SQL = "SELECT * FROM PROPIETARIO WHERE NOMBRE='"+clave+"'";
            }
            if(columna.startsWith("DOMICILIO")){
                SQL = "SELECT * FROM PROPIETARIO WHERE DOMICILIO='"+clave+"'";
            }
            if(columna.startsWith("FECHA")){
                SQL = "SELECT * FROM PROPIETARIO WHERE FECHA='"+clave+"'";
            }
            Cursor c = transaccionconsultar.rawQuery(SQL, null);
            if(c.moveToFirst()){
                resultado = new Propietario[c.getCount()];
                int pos = 0;
                do{
                    resultado[pos]=new Propietario(c.getString(0),
                            c.getString(1),c.getString(2),
                            c.getString(3));
                    pos++;
                }while (c.moveToNext());
            }
            transaccionconsultar.close();
        }catch (SQLiteException e) {
            return null;
        }
        return resultado;
    }

    public boolean eliminar(String TELEFONO) {
        int resultado=0;
        try {
            SQLiteDatabase transaccioneliminar = base.getWritableDatabase();
            String telefono[] = {TELEFONO};
            resultado = transaccioneliminar.delete("PROPIETARIO", "TELEFONO=?", telefono);
            transaccioneliminar.close();
        } catch (SQLiteException e) {
            error = e.getMessage();
            return false;
        }
        return resultado>0;
    }

    public boolean actualizar(Propietario p){
        try {
            SQLiteDatabase transaccionactualizar = base.getWritableDatabase();
            ContentValues datos = new ContentValues();
            String telefono[] = {p.getTelefono()};
            datos.put("NOMBRE",p.getNombre());
            datos.put("DOMICILIO",p.getDomicilio());
            datos.put("FECHA",p.getFecha());
            long resultado = transaccionactualizar.update("PROPIETARIO",
                    datos, "TELEFONO=?", telefono);
            transaccionactualizar.close();
            if (resultado == -1) return false;
        }catch (SQLiteException e){
            error = e.getMessage();
            return false;
        }
        return true;
    }


    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String tel) {
        telefono = tel;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nom) {
        nombre = nom;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String dom) {
        domicilio = dom;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fe) {
        fecha = fe;
    }
}
